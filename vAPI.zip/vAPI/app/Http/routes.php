<?php

use App\Api;


/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

//Routes this url to this controller
Route::resource('send','Controller_Logs');



//REsoure + Controller acting weird. I don't have time to waste on that.
//Will figure out later.


// Character Count = 81 
//logs/actionTypes/users/activities/course/modules/activities/sessions/performance

//This one v is a Doozy. As it will need to create a Seperate JSON struct for 
// EACH Component Entry
//logs/actionTypes/users/activities/course/modules/activities/sessions/components

//logs/actionTypes/users/activities/course/modules/activities/sessions/initStates

//logs/actionTypes/users/activities/course/modules/activities/sessions/currStates

//logs/actionTypes/failedLogins
//logs/

//MouseLogs


// Courses Hierarchy :  

Route::get('/courses', function()
{
	#Check Required Parameters : user_ID and Session_Key
	if(Api\Login_Checker::Check_Credentials())
	{
		//Do What we want.



	}
	else
		//Display 404 Error, Because Credentials did not pass Checks.
		abort(404, 'Invalid Credentials');
});



//- Post Requests Per Table.
//Choose a Table, set the correct Parameters,
//Ensure you have a valid user_ID/SessionKey
//And Boom Fire Away!
//---------------------------------------------------------------

Route::post('/courses', function()
{
	#Check Required Parameters : user_ID and Session_Key
	if(Api\Login_Checker::Check_Credentials())
	{
		//Do What we want.

		//Add Entry to Logs
		$success = Api\Set_Record_Courses::Set_Record();

		if(!$success)
			return 'Record Failed to insert, please check all required parameters.';
		else
			return 'Record was Successfully inserted.';


	}
	else
	//Display 404 Error, Because Credentials did not pass Checks.
	abort(404, 'Invalid Credentials');
});

Route::post('/logs', function()
{
	#Check Required Parameters : user_ID and Session_Key
	if(Api\Login_Checker::Check_Credentials())
	{
		//Do What we want.

		//Add Entry to Logs
		$success = Api\Set_Record_Logs::Set_Record();

		if(!$success)
			return 'Record Failed to insert, please check all required parameters.';
		else
			return 'Record was Successfully inserted.';


	}
	else
	//Display 404 Error, Because Credentials did not pass Checks.
	abort(404, 'Invalid Credentials');
});

//===============================================================












