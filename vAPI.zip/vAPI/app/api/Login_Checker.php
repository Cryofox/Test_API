<?php 
namespace App\Api;
use DB;
use Request;

class Login_Checker
{

	public static function Check_Credentials()
	{
		//If the Request is missing eithor of these fields we return false.
		if((Request::has('user_ID')) && (Request::has('session_Key')))
		{

			//Before ANY ROUTE REQUEST!
			//Check if the user has correct credentials
			$results = self::isCorrect_Credentials(Request::input('user_ID'),Request::input('session_key'));
			if(!$results)
				return false;

			//If we make it to this line then there were no invalid credentials.

			//Now we can Perform the Action 
			 return true;
		}

		return false;
	}

	private static function isCorrect_Credentials($user_ID, $user_SessionKey)
	{
		// if(!Check_UserID($user_ID))
		// 	return false;
		if((self::Check_UserID($user_ID)) &&
		   (self::Check_SessionKey($user_SessionKey)))
			return true;

		return false;
	}




	//This is a skeleton untill Zach informs me how Session Keys are generated :P
	private static function Check_SessionKey($sessionKey)
	{
		return true;
	}




	//Returns True if UserID exists in table
	private static function Check_UserID($user_ID)
	{

		$results= DB::select('select * from tbl_users where id = ?',[$user_ID]);	 //index 1 = Query
		if( count($results) == 1) //ids are unique, 
			return true;

		return false;
	}

}