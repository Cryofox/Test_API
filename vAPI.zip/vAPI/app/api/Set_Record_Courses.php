<?php 
namespace App\Api;
use DB;
use Request;
use Carbon\Carbon;
class Set_Record_Courses
{
	# We will ONLY perform a store if all Parameters are in place.
	public static function Set_Record()
	{
		if( 			
			(!Request::has('course_Code')) 		||
			(!Request::has('course_Name'))	
		   )
			return false;

		//We have all the Required Parameters. We might be missing (Description) but thats okay.
		// return Carbon::now();
		DB::table('tbl_Courses')->insert(
			[
			    [
					'course_Code'			=> 	Request::input('course_Code'),
					'course_Name'			=> 	Request::input('course_Name')
			    ]
			]
		);


		return true;
	}

}