<?php 
namespace App\Api;
use DB;
use Request;
use Carbon\Carbon;
class Set_Record_Logs
{
	# We will ONLY perform a store if all Parameters are in place.
	public static function Set_Record()
	{
		if( 
			// (!Request::has('dateCreated')) 	||
			// (!Request::has('description')) 	||				
			(!Request::has('actionType_ID')) 		||
			(!Request::has('activitySession_ID'))	||
			(!Request::has('user_ID'))
		   )
			return false;

		//We have all the Required Parameters. We might be missing (Description) but thats okay.
		// return Carbon::now();
		DB::table('tbl_Logs')->insert(
			[
			    [
				    'dateCreated' 			=>  Request::input('dateCreated',Carbon::now()), 
				    'description' 			=> 	Request::input('description','--No Description--'),
					'actionType_ID'			=> 	Request::input('actionType_ID'),
					'activitySession_ID'	=>  Request::input('activitySession_ID'),
					'user_ID'				=>  Request::input('user_ID')
			    ]
			]
		);


		return true;
	}

}