<?php

class Query extends Eloquent{


	public function scopeSearch($query,$search)
	{



	}




}






